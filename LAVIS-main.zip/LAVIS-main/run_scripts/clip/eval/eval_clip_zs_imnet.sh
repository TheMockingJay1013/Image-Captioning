python -m torch.distributed.run --nproc_per_node=8 evaluate.py --cfg-path lavis/projects/clip/exp_imnet_zs_eval.yaml # --options run.num_workers=0
