python -m torch.distributed.run --nproc_per_node=1 evaluate.py --cfg-path lavis/projects/clip/exp_flickr_ret_eval.yaml
