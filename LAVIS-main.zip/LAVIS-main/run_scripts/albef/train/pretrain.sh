python -m torch.distributed.run --nproc_per_node=16 train.py --cfg-path lavis/projects/albef/train/pretrain.yaml
