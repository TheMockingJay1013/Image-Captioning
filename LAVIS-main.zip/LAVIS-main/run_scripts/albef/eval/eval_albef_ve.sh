python -m torch.distributed.run --nproc_per_node=16 evaluate.py --cfg-path lavis/projects/albef/eval/snli_ve_eval.yaml
