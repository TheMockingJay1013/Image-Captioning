python -m torch.distributed.run --nproc_per_node=16 train.py --cfg-path lavis/projects/blip/train/okvqa_ft.yaml
