python -m torch.distributed.run --nproc_per_node=16 train.py --cfg-path lavis/projects/blip/vqav2_ft.yaml
