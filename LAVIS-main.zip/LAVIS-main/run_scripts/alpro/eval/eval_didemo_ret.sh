python -m torch.distributed.run --nproc_per_node=8 evaluate.py --cfg-path lavis/projects/alpro/eval/didemo_ret_eval.yaml
